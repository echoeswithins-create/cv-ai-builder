import React from "react";
import BuilderPage from "./components/BuilderPage";
import "./styles/builder.css";

function App() {
  return <BuilderPage />;
}

export default App;
